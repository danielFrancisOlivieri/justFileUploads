import React from 'react';
import '../../css/ExtraInfo.css';

 
export class AdditionalTripInformation extends React.Component{

  render() {
  return (

<div className="ExtraInfoClassName AdditionalTripInfoClassName">
 
<span className="orange">ADDITIONAL INFO: </span>
<br/>
<p className="IncludedInformationParagraphClassName"  > 
<span className="orange pika"> hiker </span> <span></span> <span> <pre>  Hiking</pre>  </span> 
</p>
<p className="IncludedInformationParagraphClassName"  > 
<span className="orange pika watch"> Watch    </span> <span>  </span>
<div className="vertical" > 9km 
  +800m 
  -400m </div> 
</p>


</div>

  )

  }

}

export default AdditionalTripInformation;