import React from 'react';
import '../../css/BottomRightInformation.css';
import '../../css/ExtraInfo.css';


export class BottomRightInformation extends React.Component{

  render() {
  return (
      <div className="BottomRightInformationClassName ExtraInfoClassName">
<span className="orange"> {this.props.title} </span>
<br/>
<p className="IncludedInformationParagraphClassName"  > 
<span className="orange pika"> {this.props.firstItemName} </span> <span></span> <span> <pre>  {this.props.firstItemContents}</pre>  </span> 
</p>
<p className="IncludedInformationParagraphClassName"  > 
<span className="orange pika watch"> {this.props.secondItemName}    </span> <span>  </span>
<div className="vertical" > {this.props.secondItemContents}</div> 
</p>
 

</div>

 
  )

  }


}

export default BottomRightInformation;