import React from 'react';
import '../../css/ExtraInfo.css';


export class IncludedInformation extends React.Component{

  render() {
  return ( 

<div className="ExtraInfoClassName IncludedInformationClassName">

<span className="orange"  >INCLUDED: </span>
<br/>
<p className="IncludedInformationParagraphClassName"  > 
<span className="orange pika"> bed </span> <span className="PlainFont"> hotel </span> 
</p>
<p className="IncludedInformationParagraphClassName"  >  
<span className="orange pika"> Utensils </span> <span className="PlainFont"> Breakfast, dinner </span> 
</p>
</div>

  )

  }

}

export default IncludedInformation;