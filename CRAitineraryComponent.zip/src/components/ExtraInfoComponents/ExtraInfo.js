import React from 'react';
import '../../css/ExtraInfo.css';
import BottomRightInformation from './BottomRightInformation';


export class ExtraInfo extends React.Component{

  render() {
  return (
      <div className="ExtraInfoContainerClassName">

<BottomRightInformation 
title="INCLUDED:"
firstItemName="bed"
firstItemContents="Hotel"
secondItemName="utensils"
secondItemContents="Breakfast, dinner"

></BottomRightInformation>

<BottomRightInformation
title="ADDITIONAL INFO:"
firstItemName="hiker"
firstItemContents="Hiking"
secondItemName="watch"
secondItemContents="9km +800m -400m"


></BottomRightInformation>

      </div>
 
  )

  }


}

export default ExtraInfo;