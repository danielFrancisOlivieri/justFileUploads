import React from 'react';
import '../../App.css';
import '../../css/Map.css';
import ReactMapboxGl, { Layer, Feature, ZoomControl, RotationControl  } from "react-mapbox-gl";

const ReactMap = ReactMapboxGl({
  accessToken: "pk.eyJ1IjoiZGFuaWVsZnJhbmNpc29saXZpZXJpIiwiYSI6ImNqaHJ3czRlZDJycnAzYXF3Ym1qYXFvNXUifQ.mh_3nSYT7hxHhXj4t48cHA",
  doubleClickZoom: false, 
});

export class Map extends React.Component{

    render() {
  return (

<div>
<ReactMap

  style="mapbox://styles/mapbox/streets-v9"
  containerStyle={{
    height: "500px",
    width: "620px"
  }}>

  <ZoomControl
  position="top-left"
  />

<RotationControl
  position="top-left"
/>

    <Layer
      type="symbol"
      id="marker"
      layout={{ "icon-image": "marker-15" }}>
      <Feature coordinates={[-0.481747846041145, 51.3233379650232]}/>
    </Layer>
</ReactMap>
</div>


  )

    }

}

export default Map;