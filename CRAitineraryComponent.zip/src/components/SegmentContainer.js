import React from 'react';
import '../App.css';
import Heading from "./HeadingComponents/Heading";
import Map from './MapComponents/Map';
import DayTime from './DayInformationComponents/DayTime';
import Description from './DescriptionComponents/Description';

import ExtraInfo from './ExtraInfoComponents/ExtraInfo';


import { Grid } from 'semantic-ui-react'

export class SegmentContainer extends React.Component{

  render() {
  return (

    <div className="body">
  
<div className="content">

<Heading></Heading>
      
<Map></Map>

<DayTime

DayNumber = "1"
NumberOfDays = "12"
StartTime = "9:00"
EndTime = "20:00"
TotalTime = "11"

></DayTime> 


<Grid className="DescriptionGridClassName" >
    <Grid.Column width={9} className="DescriptionInSegmentContainerClassName"  >
    <Description></Description>
    </Grid.Column>
    <Grid.Column  >      
   <ExtraInfo className="alignRight"></ExtraInfo>
    </Grid.Column>

</Grid>


      </div>
      </div>   

  );
  }
}


export default SegmentContainer;