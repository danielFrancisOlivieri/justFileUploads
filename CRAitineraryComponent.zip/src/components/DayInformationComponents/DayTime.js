import React from 'react';
import '../../App.css';
import '../../css/DayTime.css';

export class DayTime extends React.Component{

  render() {
  return (
 
<div className="DayTimeParagraphClassName"  > 
<span className="orange" >
DAY</span> <span> </span>
<span className="orange">
{this.props.DayNumber}
</span> <span> </span>



 / {this.props.NumberOfDays} | {this.props.StartTime} - {this.props.EndTime} ({this.props.TotalTime} hrs)

</div>

  )

  }

}

export default DayTime;