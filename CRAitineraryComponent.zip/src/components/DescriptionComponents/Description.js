import React from 'react';
import '../../css/Description.css';
import DescriptionTitle from './DescriptionTitle';
import DescriptionDivider from './DescriptionDivider';
import DescriptionText from './DescriptionText';
import DirectionButtons from './DirectionButtons';


let title = "Arrival in the Art Nouveau town of Ålesund"
let text = "Alesund is known for its Art Nouveau architecture and incredible hiking opportunities. The town harbours the world-known sea voyage Hurtigruten Coastal Express on a daily basis. After arriving in Alesund, you meet the guide and the rest of the group in the evening for a brief at 7 pm at the hotel. The group will then go to a nice restaurant in the city to have dinner together.";


export class Description extends React.Component{

  render() {
  return (
      <div className="DescriptionName">

<DescriptionTitle
descriptionTitle={title}
></DescriptionTitle>

<DescriptionDivider/>

<DescriptionText 
descriptionText={text}
 ></DescriptionText>

<DirectionButtons></DirectionButtons>

      </div>

  )

  }


}

export default Description;