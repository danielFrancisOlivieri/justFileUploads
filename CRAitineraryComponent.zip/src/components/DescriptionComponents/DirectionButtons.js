import React from 'react';
import '../../App.css';
import '../../css/DirectionButtons.css';

function DirectionButtons () {
  return (
  

<div className="DirectionButtons">

<img src='https://raw.githubusercontent.com/danielFrancisOlivieri/justFileUploads/master/leftArrow.png' alt="Left Arrow Icon" ></img>
<span>  </span>
<img src='https://raw.githubusercontent.com/danielFrancisOlivieri/justFileUploads/master/rightArrow.png' alt="Right Arrow Icon" ></img>

</div>

  );
}

export default DirectionButtons;
