import React from 'react';
import '../../App.css';
import '../../css/DescriptionText.css';


export class DescriptionText extends React.Component{

  render() {
  return (

    <p className="descriptionTextClass" >
    {this.props.descriptionText}
    </p>

  )
 
  }
}

export default DescriptionText;