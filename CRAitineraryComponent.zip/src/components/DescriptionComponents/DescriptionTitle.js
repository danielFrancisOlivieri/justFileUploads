import React from 'react';
import '../../App.css';
import '../../css/DescriptionTitle.css';


export class DescriptionTitle extends React.Component{

  render() {
  return (
      <p className="DescriptionTitleClassName" >
      {this.props.descriptionTitle}
      </p>
  )

  }
}

export default DescriptionTitle;