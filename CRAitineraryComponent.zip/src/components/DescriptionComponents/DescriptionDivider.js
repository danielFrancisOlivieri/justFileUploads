import React from 'react';
import '../../App.css';
import '../../css/DescriptionDivider.css';


export class DescriptionDivider extends React.Component{

  render() {
  return (
<div>
<hr />
</div>
  )

  }
}

export default DescriptionDivider;