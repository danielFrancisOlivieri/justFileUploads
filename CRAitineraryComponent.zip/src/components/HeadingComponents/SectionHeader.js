import React from 'react';
import '../../App.css';
import '../../css/sectionHeader.css';


export class SectionHeader extends React.Component{

    render() {
  return (

 <p className="sectionHeaderParagraph" >
        {this.props.text}
    </p>

  );


}
}


export default SectionHeader;