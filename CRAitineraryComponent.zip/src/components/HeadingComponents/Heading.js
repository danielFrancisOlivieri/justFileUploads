import React from 'react';
import '../../App.css';
import '../../css/Heading.css';
import SupraTitle from './SupraTitle';
import SectionHeader from './SectionHeader';

export class Heading extends React.Component{

  render() {
  return (

    <div className="HeadingClassName">

<SupraTitle
text="ITINERARY"
> </SupraTitle>

<SectionHeader
text="Explore this trip"
></SectionHeader>

    </div>

  )

  }
}

export default Heading;