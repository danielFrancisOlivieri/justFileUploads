import React from 'react';
import '../../App.css';
import '../../css/supraTitle.css';


export class SupraTitle extends React.Component{

    render() {
  return (

    <p className="supraTitleParagraph" >
        {this.props.text}
    </p>


  );

}
}


export default SupraTitle;