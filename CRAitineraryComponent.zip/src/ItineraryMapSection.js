import React from 'react';
import './App.css';
import SegmentContainer from './components/SegmentContainer'

function ItineraryMapSection () {
  return (
    <div className="body" >

<SegmentContainer></SegmentContainer>

    </div>
  );
}

export default ItineraryMapSection;
