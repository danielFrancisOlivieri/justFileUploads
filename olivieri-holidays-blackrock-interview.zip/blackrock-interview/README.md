## Read Me 

This is an application that generates csv of national holidays based on user input. 

### Ways I Think This Exercise Could Potentially Be Improved

I like that you advise against using external depedencies. This likely makes the code a bit easier to read and gives a sense of what a programmer can do themself without leaning on external libraries to do the heavy lifting. 

I also like that you specify that version control should be managed using Git. If I were the recruiter, I would want to require that people taking this assessment make all their commits to github or a similar code hosting platform so that I could see how the project grew over time, what their individual commits looked like, and overall get a more thorough understanding of what their programming process looks like. The finished product teaches a lot, but the way someone got there can also tell you a lot. 

I would also consider asking the applicant to write something that briefly describes some of the design decisions she made. By asking what a programmer was thinking, you might learn more about their process and discover things you otherwise would not have known. It also may give them the chance to show some of their personality and critical thinking skills. 



