"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var utilities_1 = require("./utilities");
var https = require("node:https");
var fs = require("fs");
var chosenCode = "AT";
var readInput = require("readline").createInterface({
    input: process.stdin,
    output: process.stdout,
});
readInput.question("This application generates CSV files containing the holidays for various countries. \n What country would you like to get the holidays for? \n Refer to this site if you would like a list of options https://date.nager.at/Country \n \n", function (country) {
    chosenCode = (0, utilities_1.getCountryCode)(country);
    readInput.close();
    https.get("https://date.nager.at/api/v3/publicholidays/2023/".concat(chosenCode), function (response) {
        var holidayData = "";
        response.on("data", function (data) {
            holidayData += data;
        });
        var csvString = "";
        response.on("end", function () {
            var asJson = JSON.parse(holidayData);
            for (var _i = 0, asJson_1 = asJson; _i < asJson_1.length; _i++) {
                var holiday = asJson_1[_i];
                var name_1 = holiday["name"];
                var dateAsObject = new Date(holiday["date"]);
                var date = holiday["date"];
                var daysUntil = (0, utilities_1.howManyDaysUntil)(dateAsObject);
                var isHoldidayOnWeekend = (0, utilities_1.isWeekend)(dateAsObject) ? "Yes" : "No";
                csvString += " ".concat(name_1, ", ").concat(date, ", ").concat(daysUntil, ", ").concat(isHoldidayOnWeekend, ", ");
            }
            fs.writeFile("".concat(chosenCode, "_holidays.csv"), csvString, function (err) {
                if (err) {
                    console.log("error ", err);
                }
            });
        });
    });
});
