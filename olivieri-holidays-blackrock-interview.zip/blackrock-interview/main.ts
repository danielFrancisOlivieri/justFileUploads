import { getCountryCode, howManyDaysUntil, isWeekend } from "./utilities";

const https = require("node:https");

const fs = require("fs");

let chosenCode: string = "AT";

const readInput = require("readline").createInterface({
  input: process.stdin,
  output: process.stdout,
});

readInput.question(
  "This application generates CSV files containing the holidays for various countries. \n What country would you like to get the holidays for? \n Refer to this site if you would like a list of options https://date.nager.at/Country \n \n",
  (country) => {

    chosenCode = getCountryCode(country);
    readInput.close();

    https.get(
      `https://date.nager.at/api/v3/publicholidays/2023/${chosenCode}`,
      (response) => {
        let holidayData: string = "";

        response.on("data", (data) => {
          holidayData += data;
        });

        let csvString: string = "";

        response.on("end", () => {
          let asJson = JSON.parse(holidayData);
          for (let holiday of asJson) {
            let name: string = holiday["name"];
            let dateAsObject: Date = new Date(holiday["date"]);
            let date: string = holiday["date"];
            let daysUntil: string = howManyDaysUntil(dateAsObject);
            let isHoldidayOnWeekend: string = isWeekend(dateAsObject) ? "Yes" : "No";
            csvString += ` ${name}, ${date}, ${daysUntil}, ${isHoldidayOnWeekend}, `;
          }

          fs.writeFile(`${chosenCode}_holidays.csv`, csvString, (err) => {
            if (err) {
              console.log("error ", err);
            }
          });
        });
      }
    );
  }
);
